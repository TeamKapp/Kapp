package project.kapp;


import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import lib.wordclass;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WordFragment extends Fragment {

    public static WordFragment newInstance(int position) {

        WordFragment f = new WordFragment();
        Bundle b = new Bundle();
        b.putInt("position", position);

        f.setArguments(b);

        return f;
    }

    public String[][] wordmean = new String[2][5];// word:0/mean:1
    TextView tv;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_word, container, false);
        wordext we = new wordext();
        we.start();
        try {
            we.join();
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        tv = (TextView) view.findViewById(R.id.txt_word1);
        tv.setText(wordmean[0][0]);
        tv = (TextView) view.findViewById(R.id.txt_word2);
        tv.setText(wordmean[0][1]);
        tv = (TextView) view.findViewById(R.id.txt_word3);
        tv.setText(wordmean[0][2]);
        tv = (TextView) view.findViewById(R.id.txt_word4);
        tv.setText(wordmean[0][3]);
        tv = (TextView) view.findViewById(R.id.txt_word5);
        tv.setText(wordmean[0][4]);

        tv = (TextView) view.findViewById(R.id.txt_mean1);
        tv.setText(wordmean[1][0]);
        tv = (TextView) view.findViewById(R.id.txt_mean2);
        tv.setText(wordmean[1][1]);
        tv = (TextView) view.findViewById(R.id.txt_mean3);
        tv.setText(wordmean[1][2]);
        tv = (TextView) view.findViewById(R.id.txt_mean4);
        tv.setText(wordmean[1][3]);
        tv = (TextView) view.findViewById(R.id.txt_mean5);
        tv.setText(wordmean[1][4]);

        return view;
    }

    class wordext extends wordclass {
        public wordext() {
            super();
        }

        public void run() {// 그래그래
            Boolean cn = checkNetwork();

            if (cn) {
                String html = loadhtml(url);
                if (checkwordnull(html)) {
                    word = wordparse(html);
                    mean = meanparse(html);
                }
                else{

                    for(int i = 0; i<5; i++){
                        wordmean[1][i] = "필요합니다";
                        wordmean[0][i] = "인터넷 연결이 ";
                    }

                }
                wordmean = turnout();
            }
            return;
        }

        public boolean checkwordnull(String wm) {
            Pattern patwm = Pattern.compile("txt_col");
            Matcher matcherwm;
            matcherwm = patwm.matcher(wm);
            return matcherwm.find();

        }

        private boolean checkNetwork() {
            ConnectivityManager manager = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo mobile = manager
                    .getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
            NetworkInfo wifi = manager
                    .getNetworkInfo(ConnectivityManager.TYPE_WIFI);
            NetworkInfo lte_4g = manager
                    .getNetworkInfo(ConnectivityManager.TYPE_WIMAX);
            boolean blte_4g = false;
            if (lte_4g != null)
                blte_4g = lte_4g.isConnected();
            if (mobile.isConnected() || wifi.isConnected() || blte_4g)
                return true;
            else {
                return false;
            }
        }

    }
}
