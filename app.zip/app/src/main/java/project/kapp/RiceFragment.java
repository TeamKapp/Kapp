package project.kapp;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.Calendar;

public class RiceFragment extends Fragment implements View.OnClickListener{

    public static RiceFragment newInstance(int position) {

        RiceFragment f = new RiceFragment();
        Bundle b = new Bundle();
        b.putInt("position", position);

        f.setArguments(b);

        return f;
    }

    private static final int SWIPE_MIN_DISTANCE = 120;
    private static final int SWIPE_MAX_OFF_PATH = 250;
    private static final int SWIPE_THRESHOLD_VELOCITY = 200;

    private GestureDetector gestureScanner;

    private TextView riceMorning, riceLaunch, riceDinner, ricedate;
    private Button prevBtn, nextBtn, seemoreExitBtn;
    private RelativeLayout seemorerice_layout;
    private ViewGroup seedaterice;

    private int mShortAnimationDuration;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_rice, container, false);

        riceMorning = (TextView) view.findViewById(R.id.rice_mor_txt);
        riceLaunch = (TextView) view.findViewById(R.id.rice_lau_txt);
        riceDinner = (TextView) view.findViewById(R.id.rice_din_txt);
        ricedate = (TextView) view.findViewById(R.id.noti_txt);
        ricedate.setText(today());

        seedaterice = (ViewGroup)view.findViewById(R.id.date_rice);
        seedaterice.setVisibility(view.GONE);

        seemorerice_layout = (RelativeLayout) view.findViewById(R.id.rice_ll_seemore);
        seemorerice_layout.setVisibility(view.GONE);
        seemoreExitBtn = (Button) view.findViewById(R.id.btn_rice_exitseemore);
        seemoreExitBtn.setOnClickListener(this);

        mShortAnimationDuration = getResources().getInteger(android.R.integer.config_shortAnimTime);

        return view;
    }


    public void onClick(View view) {
        switch (view.getId()) {
            case (R.id.btn_rice_exitseemore):
                seemorerice_layout.setVisibility(view.GONE);
                break;
        }
    }


    static String today(){
        Calendar cal = Calendar.getInstance();
        return cal.get(Calendar.MONTH)+1+"월"+cal.get(Calendar.DATE)+"일";
    }

    private void CF_dateon() {
        seedaterice.setAlpha(0f);
        seedaterice.setVisibility(View.VISIBLE);
        seedaterice.animate().alpha(1f).setDuration(mShortAnimationDuration).setListener(null);
    }
    private void CF_dateoff() {

    }
}
